from flask import Flask, render_template, current_app, request, redirect, url_for
from google.cloud import storage


app = Flask(__name__)
@app.route('/', methods=['GET'])
def hello_world():
    return "hello"

@app.route('/add', methods=['POST'])
def add():
	#placeholder values
	value = upload_blob("placeholder-bucket", "local-path", "destination-blob")
	return value

def upload_blob(bucket_name, source_file_name, destination_blob_name):
	storage_client = storage.Client()
	bucket = storage_client.bucket(bucket_name)
	blob = bucket.blob(destination_blob_name)
	blob.upload_from_filename(source_file_name)

	return "File uploaded"
if __name__ == '__main__':
    app.run()
